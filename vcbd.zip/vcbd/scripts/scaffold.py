#!/usr/bin/env python3
"""scaffold.py — Generator kerangka deterministik paket VCBD.

Membaca docs/_MANIFEST.json (wajib sudah ditulis — Fase 3 langkah 1) lalu menulis:
  1. 26 dokumen docs/00..25 — stub final untuk nomor di field `collapsed`,
     kerangka ber-penanda `Status: KERANGKA` untuk sisanya (diisi penyusun).
  2. INDEX.md UTUH & FINAL — skrip ini SATU-SATUNYA rumah isi INDEX
     (tabel rute + kondisional, indeks per klaster, aturan emas).
     Mengubah rute = mengubah konstanta di file ini, bukan menulis manual.
  3. CLAUDE.md kerangka (bagian tetap sudah terisi; slot proyek ber-[ISI:]).
  4. Menyalin validate.sh + token_ledger.py ke scripts/ proyek (self-validate &
     meteran token downstream), dan menulis genesis docs/_TOKEN_LEDGER.json
     (titik nol akumulasi token) bila belum ada.

Anti-timpa: file yang sudah ada DILEWATI (laporan "skip"); --force untuk menimpa.
Pemakaian:  python3 scaffold.py --root /path/proyek [--force]
Keluaran boilerplate oleh skrip = nol token model + nol drift format;
model hanya menulis substansi (Hukum 4 diterapkan pada proses generasi sendiri).
"""
import argparse, json, shutil, stat, sys
from datetime import datetime, timezone
from pathlib import Path

DOCS = [
    "00_EXECUTIVE_SUMMARY", "01_PRD", "02_SCOPE", "03_ROADMAP",
    "04_DOMAIN_MODEL", "05_USER_ROLE", "06_BUSINESS_PROCESS", "07_DATA_MODEL",
    "08_ARCHITECTURE", "09_STACK", "10_DEV_ENV", "11_COMMANDS",
    "12_PROJECT_STRUCTURE", "13_TESTING", "14_ERROR_HANDLING", "15_OBSERVABILITY",
    "16_DEBUGGING_GUIDE", "17_AGENT_WORKFLOW", "18_REPAIR_RULES", "19_TASK_TEMPLATE",
    "20_GUARDRAILS", "21_SECURITY_RULES", "22_CHANGE_POLICY",
    "23_ACCEPTANCE_CRITERIA", "24_DEFINITION_OF_DONE", "25_RELEASE_CHECKLIST",
]

CLUSTERS = [
    ("00–03 Strategis", ["00_EXECUTIVE_SUMMARY", "01_PRD", "02_SCOPE", "03_ROADMAP"]),
    ("04–07 Domain", ["04_DOMAIN_MODEL", "05_USER_ROLE", "06_BUSINESS_PROCESS", "07_DATA_MODEL"]),
    ("08–12 Fondasi Teknis", ["08_ARCHITECTURE", "09_STACK", "10_DEV_ENV", "11_COMMANDS", "12_PROJECT_STRUCTURE"]),
    ("13–16 Kualitas & Operasi", ["13_TESTING", "14_ERROR_HANDLING", "15_OBSERVABILITY", "16_DEBUGGING_GUIDE"]),
    ("17–22 Perilaku-Agen", ["17_AGENT_WORKFLOW", "18_REPAIR_RULES", "19_TASK_TEMPLATE", "20_GUARDRAILS", "21_SECURITY_RULES", "22_CHANGE_POLICY"]),
    ("23–25 Gerbang Selesai", ["23_ACCEPTANCE_CRITERIA", "24_DEFINITION_OF_DONE", "25_RELEASE_CHECKLIST"]),
]

# Rute DIET v2.1: kolom "Muat" = inti minimum; kolom "Kondisional" = tambahan
# hanya bila kondisinya terpenuhi (aturan emas 1: muat minimal, eskalasi bila kurang).
ROUTES = [
    ("Fitur baru (vertical slice)", "01,02,06,07,11,23",
     "cek 02 dulu; +04 istilah domain ambigu; +05 sentuh peran/izin; +13 jenis tes baru; format task: 19 (esensi di CLAUDE)"),
    ("Ubah skema DB / migrasi", "07,11,13,22",
     "⚠️ irreversibel; 22 wajib; +04 bila entitas/istilah baru"),
    ("Perbaikan bug", "11,13,14,16,18",
     "jangan lewat scope bug; 11 utk repro+tes regresi"),
    ("Endpoint/API baru", "06,07,08,11,13,21", "21 bila sensitif"),
    ("Perubahan keamanan", "15,20,21,22", "⚠️ gerbang manusia"),
    ("Tambah peran/izin", "05,06,21", "—"),
    ("Refactor arsitektur", "04,08,22", "jangan ubah keputusan sengaja"),
    ("Observability/logging", "14,15,16", "—"),
    ("Setup lingkungan", "09,10,11,12", "—"),
    ("Rilis", "11,15,22,25", "⚠️ ikuti 25 berurutan; +24 bila butuh DoD rinci"),
    ("Strategi/scope", "00,01,02,03", "tanpa kode"),
]

GOLDEN_RULES = [
    "Ragu? Muat paling sedikit dulu (kolom Muat), tambah Kondisional/eskalasi hanya bila kurang.",
    "Task irreversibel → wajib baca 22 + minta konfirmasi.",
    "Konflik antar dokumen → berhenti, laporkan, minta keputusan.",
    "Patokan selesai = 23 + 24, bukan kesempurnaan.",
    "Brownfield: dokumen ≠ kode aktual → KODE menang, hentikan & lapor selisih (lihat presedensi sumber kebenaran).",
    "23 hanya memuat fitur AKTIF. Fitur yang sudah diterima (kriteria terpenuhi, tes hijau) diarsipkan ke docs/_archive/23-{fitur}.md — penegakannya pindah ke test suite.",
]

MARKER = "Status: KERANGKA"

STUB_TMPL = """# {nn} — {name}
Tanpa penyimpangan proyek — ikuti baku (esensi diringkas di CLAUDE.md bila relevan). Dokumen sengaja dikolaps; terdaftar di `collapsed` pada `docs/_MANIFEST.json`.
"""

SKEL_TMPL = """# {nn} — {name}

> {marker} — dihasilkan `scripts/scaffold.py`. Isi substansi sesuai template {doc} di `references/template-dokumen.md` §3 (rubrik token §2), lalu HAPUS baris status ini.

[ISI: konten {doc} dari _MANIFEST.json]
"""

CLAUDE_TMPL = """# CLAUDE.md

> {marker} — dihasilkan `scripts/scaffold.py`. Isi tiap [ISI: …] sesuai panduan `template-dokumen.md` §4, lalu HAPUS baris status ini.

File ini selalu aktif. Untuk hal di luar ini → buka INDEX.md.

## Proyek
{app} — [ISI: satu kalimat]. Detail: docs/00_EXECUTIVE_SUMMARY.md. Scope: docs/02_SCOPE.md.

## Prinsip kerja agen (non-negotiable)
1. Friksi sebanding irreversibilitas.
2. Lapisan deterministik (validasi, constraint, tes) di bawah penalaran.
3. Human-in-the-loop untuk high-stakes (migrasi DB, hapus data, keamanan, rilis).
4. Jangan refactor keputusan yang disengaja diam-diam.
5. Hormati scope (docs/02). Out-of-scope → berhenti & tanya.

## Stack  (sumber: docs/09)
[ISI: ringkas] — Terlarang: [ISI: daftar]

## Struktur & konvensi  (sumber: docs/12)
[ISI: 2–4 aturan terpenting]

## Perintah penting  (sumber: docs/11)
[ISI: 4 perintah tersering — WAJIB termasuk test & migrasi ⚠️]

## Guardrail inti  (penuh: docs/20, 21, 22)
[ISI: 5–7 "JANGAN" terpenting]

## Alur per-task  (penuh: docs/17, 19)
Baca INDEX.md → muat dokumen relevan → konfirmasi scope → vertical slice → tes (docs/13) → DoD (docs/24).

## Definisi selesai (ringkas; penuh: docs/24)
[ISI: esensi]

## Untuk apa pun di luar ini → INDEX.md
"""


def build_index() -> str:
    lines = [
        "# INDEX — Peta Konteks",
        "Untuk AI: baca ini sebelum task. Muat hanya dokumen yang ditunjuk. JANGAN muat semua.",
        "",
        "## Tier 0 — selalu aktif",
        "CLAUDE.md (inti). Jangan baca ulang sumbernya kecuali butuh detail.",
        "Esensi 17_AGENT_WORKFLOW (alur per-task) & 19_TASK_TEMPLATE (format task) sudah diringkas di CLAUDE.md — keduanya sengaja TIDAK ada di rute task. Muat dokumen penuhnya hanya saat butuh detail alur/format, bukan tiap task.",
        "",
        "## Rute: jenis task → dokumen",
        "| Jenis task | Muat (inti) | Kondisional / catatan |",
        "|---|---|---|",
    ]
    for task, load, note in ROUTES:
        lines.append(f"| {task} | {load} | {note} |")
    lines += ["", "## Indeks per klaster (path: docs/NN_NAMA.md)"]
    for label, docs in CLUSTERS:
        lines.append(f"- {label}: " + " · ".join(d.split('_', 1)[1] for d in docs))
    lines += ["", "## Aturan emas"]
    lines += [f"{i}. {r}" for i, r in enumerate(GOLDEN_RULES, 1)]
    return "\n".join(lines) + "\n"


def main() -> int:
    ap = argparse.ArgumentParser(description="Generator kerangka deterministik VCBD")
    ap.add_argument("--root", default=".", help="root proyek (berisi/akan berisi docs/)")
    ap.add_argument("--force", action="store_true", help="timpa file yang sudah ada")
    a = ap.parse_args()

    root = Path(a.root).resolve()
    docs = root / "docs"
    manifest_p = docs / "_MANIFEST.json"
    if not manifest_p.is_file():
        print(f"[GAGAL] {manifest_p} tidak ditemukan. Tulis manifest dulu (Fase 3 langkah 1).")
        return 2
    try:
        m = json.loads(manifest_p.read_text(encoding="utf-8"))
    except Exception as e:
        print(f"[GAGAL] _MANIFEST.json bukan JSON valid: {e}")
        return 2

    app = (m.get("app") or {}).get("name") or "Proyek"
    collapsed = {str(x).zfill(2) for x in (m.get("collapsed") or [])}
    unknown = collapsed - {d[:2] for d in DOCS}
    if unknown:
        print(f"[PERINGATAN] nomor di `collapsed` tak dikenal, diabaikan: {sorted(unknown)}")

    created, skipped = [], []

    def write(path: Path, text: str):
        if path.exists() and not a.force:
            skipped.append(str(path.relative_to(root)))
            return
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding="utf-8")
        created.append(str(path.relative_to(root)))

    for doc in DOCS:
        nn, name = doc[:2], doc.split("_", 1)[1]
        body = (STUB_TMPL.format(nn=nn, name=name) if nn in collapsed
                else SKEL_TMPL.format(nn=nn, name=name, doc=doc, marker=MARKER))
        write(docs / f"{doc}.md", body)

    write(root / "INDEX.md", build_index())
    write(root / "CLAUDE.md", CLAUDE_TMPL.format(app=app, marker=MARKER))

    here = Path(__file__).resolve().parent
    for tool in ("validate.sh", "token_ledger.py"):
        src, dst = here / tool, root / "scripts" / tool
        if not src.is_file():
            print(f"[PERINGATAN] {tool} tidak ditemukan di samping scaffold.py — dilewati.")
            continue
        if dst.exists() and not a.force:
            skipped.append(f"scripts/{tool}")
        else:
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)
            dst.chmod(dst.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
            created.append(f"scripts/{tool}")

    # Genesis buku besar token — "start awal" akumulasi; sekali, hanya bila ledger belum ada.
    ledger = docs / "_TOKEN_LEDGER.json"
    if not ledger.exists():
        now = datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")
        pkg = [root / "CLAUDE.md", root / "INDEX.md"] + sorted(docs.glob("[0-9][0-9]_*.md"))
        chars = sum(len(p.read_text(encoding="utf-8", errors="replace")) for p in pkg if p.is_file())
        cpt = 3.5
        ledger.write_text(json.dumps({
            "meta": {"created": now, "unit": "token", "cpt_default": cpt},
            "est_entries": [{"ts": now, "type": "genesis", "task": "paket lahir (scaffold)",
                             "route": "-", "files": len(pkg), "chars": chars,
                             "cpt": cpt, "est_tokens": round(chars / cpt)}],
            "measured_sessions": {}}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        created.append("docs/_TOKEN_LEDGER.json")

    print(f"Scaffold selesai untuk '{app}'.")
    print(f"  dibuat : {len(created)} file" + (f" — {', '.join(created[:6])}{'…' if len(created) > 6 else ''}" if created else ""))
    print(f"  dilewati (sudah ada): {len(skipped)} file" + (f" — {', '.join(skipped[:6])}{'…' if len(skipped) > 6 else ''}" if skipped else ""))
    if collapsed:
        print(f"  stub (collapsed): {', '.join(sorted(collapsed))}")
    print("Langkah berikut: isi dokumen ber-penanda 'Status: KERANGKA' + CLAUDE.md, lalu jalankan `bash scripts/validate.sh`.")
    print("Meteran token (opsional): `python3 scripts/token_ledger.py log --route \"<rute>\"` per task; rekap: `... report`.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
